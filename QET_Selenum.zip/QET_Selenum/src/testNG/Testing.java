package testNG;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class Testing {

	private WebDriver driver;
	static List<String[]> product;
	static List<String[]> priceList;
	List<String[]> registration;
	List<String[]> orderConfirmation;
	List<String[]> orderHistory;
	String totalPrice;
	String totalShipping;
	String total;
	Registration reg;
	Product tShirt;	
	Product blouse;
	Product dress;
	WebDriverWait wait;
	
	@BeforeClass
	public void OneTimeSetup(){
		product = new ArrayList<String[]>();
		priceList = new ArrayList<String[]>();
		registration = new ArrayList<String[]>();
		orderConfirmation = new ArrayList<String[]>();
		orderHistory = new ArrayList<String[]>();		
		
		tShirt = new Product();
		tShirt.setName("Faded Short Sleeve T-shirts");		
		tShirt.setSize("L");
		tShirt.setQty(12);
		tShirt.setPrice((float) 10.00);		

		blouse = new Product();
		blouse.setName("Blouse");		
		blouse.setSize("M");
		blouse.setQty(15);
		
		dress = new Product();
		dress.setName("Printed Chiffon Dress");		
		dress.setSize("S");
		dress.setQty(10);
		
		reg = new Registration();
		reg.setFirstName("Test");
		reg.setLastName("User");
		reg.setAddress("Colorado");
		reg.setCity("Bakersfield");
		reg.setState("California");
		reg.setPostalCode("90015");
		reg.setCountry("United States");
		reg.setMobile("34235345455");		
	}
	
	@BeforeMethod
	public void Setup() throws Exception {
		
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin\\Desktop\\QET\\chromedriver.exe");

		driver = new ChromeDriver();
		wait = new WebDriverWait(driver, 5);		
		driver.manage().window().maximize();
		driver.get("http://automationpractice.com/index.php");
	}

	@Test
	public void RegisterAccount() throws IOException {		
		WebElement signInButton = driver.findElement(By.className("login"));
		signInButton.click();

		wait.until(ExpectedConditions.elementToBeClickable(By.id("email_create")));

		WebElement emailTextBox = driver.findElement(By.id("email_create"));

		String emailAddress = getUsername() + "@gmail.com";
		emailTextBox.sendKeys(emailAddress);

		WebElement createAccountButton = driver.findElement(By.id("SubmitCreate"));
		createAccountButton.click();

		wait.until(ExpectedConditions.elementToBeClickable(By.id("id_gender1")));

		WebElement buttonradio = driver.findElement(By.id("id_gender1"));
		buttonradio.click();

		WebElement firstName = driver.findElement(By.id("customer_firstname"));
		firstName.sendKeys(reg.getFirstName());

		WebElement lastname = driver.findElement(By.id("customer_lastname"));
		lastname.sendKeys(reg.getLastName());

		WebElement password = driver.findElement(By.id("passwd"));
		password.sendKeys("123456");

		Select daysDropDown = new Select(driver.findElement(By.id("days")));
		daysDropDown.selectByValue("12");

		Select monthsDropDown = new Select(driver.findElement(By.id("months")));
		monthsDropDown.selectByValue("9");

		Select yearsDropDown = new Select(driver.findElement(By.id("years")));
		yearsDropDown.selectByValue("1991");

		WebElement addressOne = driver.findElement(By.id("address1"));
		addressOne.sendKeys(reg.getAddress());

		WebElement city = driver.findElement(By.id("city"));
		city.sendKeys(reg.getCity());

		Select state = new Select(driver.findElement(By.id("id_state")));
		state.selectByVisibleText(reg.getState());

		WebElement postCode = driver.findElement(By.id("postcode"));
		postCode.sendKeys(reg.getPostalCode());

		Select countrySelect = new Select(driver.findElement(By.id("id_country")));
		countrySelect.selectByVisibleText(reg.getCountry());

		WebElement phoneMobile = driver.findElement(By.id("phone_mobile"));
		phoneMobile.sendKeys(reg.getMobile());

		WebElement submitAccount = driver.findElement(By.id("submitAccount"));
		submitAccount.click();
		
		registration.add(new String[] {"First Name", reg.getFirstName()});
		registration.add(new String[] {"Last Name", reg.getLastName()});
		registration.add(new String[] {"Address", reg.getAddress()});
		registration.add(new String[] {"City", reg.getCity()});
		registration.add(new String[] {"State", reg.getState()});
		registration.add(new String[] {"Postal Code", reg.getPostalCode()});
		registration.add(new String[] {"Country", reg.getCountry()});
		registration.add(new String[] {"Mobile", reg.getMobile()});
		
		shopForBlouse();
		shopForDress();
		shopForTShirt();
		
		checkOut();
	}
	
	private void shopForBlouse(){
		wait.until(ExpectedConditions.elementToBeClickable(By.id("search_query_top")));

		WebElement searchbox = driver.findElement(By.id("search_query_top"));
		searchbox.sendKeys(blouse.getName());

		WebElement searchButton = driver.findElement(By.name("submit_search"));
		searchButton.click();

		WebElement blouseImage = driver.findElement(By.className("product_img_link"));
		blouseImage.click();

		wait.until(ExpectedConditions.elementToBeClickable(By.id("quantity_wanted")));

		WebElement quantityWanted = driver.findElement(By.id("quantity_wanted"));
		quantityWanted.clear();
		quantityWanted.sendKeys(blouse.getQty().toString());

		WebElement model = driver.findElement(By.cssSelector("[itemprop='sku']"));
		blouse.setSku(model.getText());
		
		Select blouseSize = new Select(driver.findElement(By.id("group_1")));
		blouseSize.selectByVisibleText(blouse.getSize());

		WebElement color = driver.findElement(By.id("color_11"));
		color.click();
		blouse.setColor(color.getAttribute("name"));	
		
		WebElement price = driver.findElement(By.id("our_price_display"));
		blouse.setPrice(Float.parseFloat(price.getText().substring(1)) * blouse.getQty());
		
		WebElement addToCart = driver.findElement(By.name("Submit"));
		addToCart.click();
		
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("[title='Continue shopping'] span")));

		WebElement backToshopping = driver.findElement(By.cssSelector("[title='Continue shopping'] span"));
		backToshopping.click();
		
		product.add(new String[] {blouse.getName(), blouse.getColor(), blouse.getSize(), blouse.getSku(), blouse.getQty().toString(), blouse.getPrice().toString() });
		
		totalPrice = String.valueOf((blouse.getPrice() * blouse.getQty()));
		totalShipping = String.valueOf(2);
		total = String.valueOf((blouse.getPrice() * blouse.getQty()) + 2);
		priceList.add(new String[] {totalPrice, totalShipping, total});
	}
	
	private void shopForDress() {				
		wait.until(ExpectedConditions.elementToBeClickable(By.id("search_query_top")));

		WebElement searchbox = driver.findElement(By.id("search_query_top"));
		searchbox.clear();
		searchbox.sendKeys(dress.getName());

		WebElement submitSearch = driver.findElement(By.name("submit_search"));
		submitSearch.click();

		WebElement dressclick = driver.findElement(By.className("product_img_link"));
		dressclick.click();

		wait.until(ExpectedConditions.elementToBeClickable(By.id("quantity_wanted")));
		WebElement quantity = driver.findElement(By.id("quantity_wanted"));
		quantity.clear();
		quantity.sendKeys(dress.getQty().toString());
		
		WebElement model = driver.findElement(By.cssSelector("[itemprop='sku']"));
		dress.setSku(model.getText());

		Select size = new Select(driver.findElement(By.id("group_1")));
		size.selectByVisibleText(dress.getSize());

		WebElement color = driver.findElement(By.id("color_15"));
		color.click();
		dress.setColor(color.getAttribute("name"));	
		
		WebElement price = driver.findElement(By.id("our_price_display"));
		dress.setPrice(Float.parseFloat(price.getText().substring(1)) * dress.getQty());
		
		WebElement AddToCart = driver.findElement(By.name("Submit"));
		AddToCart.click();

		product.add(new String[] {dress.getName(), dress.getColor(), dress.getSize(), dress.getSku(), dress.getQty().toString(), dress.getPrice().toString() });
		
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("[title='Continue shopping'] span")));
		
		WebElement backToshopping = driver.findElement(By.cssSelector("[title='Continue shopping'] span"));
		backToshopping.click();
		
		totalPrice = String.valueOf((dress.getPrice() * dress.getQty()));
		totalShipping = String.valueOf(2);
		total = String.valueOf((dress.getPrice() * dress.getQty()) + 2);
		priceList.add(new String[] {totalPrice, totalShipping, total});
	}
	
	private void shopForTShirt() {	
		wait.until(ExpectedConditions.elementToBeClickable(By.id("search_query_top")));

		WebElement searchbox = driver.findElement(By.id("search_query_top"));
		searchbox.clear();
		searchbox.sendKeys(tShirt.getName());

		WebElement submitSearch = driver.findElement(By.name("submit_search"));
		submitSearch.click();

		WebElement tShirtclick = driver.findElement(By.className("product_img_link"));
		tShirtclick.click();

		wait.until(ExpectedConditions.elementToBeClickable(By.id("quantity_wanted")));
		WebElement quantity = driver.findElement(By.id("quantity_wanted"));
		quantity.clear();
		quantity.sendKeys(tShirt.getQty().toString());

		WebElement model = driver.findElement(By.cssSelector("[itemprop='sku']"));
		tShirt.setSku(model.getText());

		Select size = new Select(driver.findElement(By.id("group_1")));
		size.selectByVisibleText(tShirt.getSize());

		WebElement color = driver.findElement(By.id("color_14"));
		color.click();
		tShirt.setColor(color.getAttribute("name"));
		
		WebElement price = driver.findElement(By.id("our_price_display"));
		tShirt.setPrice(Float.parseFloat(price.getText().substring(1)) * tShirt.getQty());
		
		WebElement AddToCart = driver.findElement(By.name("Submit"));
		AddToCart.click();

		product.add(new String[] {tShirt.getName(), tShirt.getColor(), tShirt.getSize(), tShirt.getSku(), tShirt.getQty().toString(), tShirt.getPrice().toString() });
		
		wait.until(ExpectedConditions.elementToBeClickable(By.cssSelector("a[title='Proceed to checkout'] > span")));		
		WebElement checkout = driver.findElement(By.cssSelector("a[title='Proceed to checkout'] > span"));
		checkout.click();
		
		totalPrice = String.valueOf((tShirt.getPrice() * tShirt.getQty()));
		totalShipping = String.valueOf(2);
		total = String.valueOf((tShirt.getPrice() * tShirt.getQty()) + 2);
		priceList.add(new String[] {totalPrice, totalShipping, total});
	}

	private String getUsername() {
		String SALTCHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890";
		StringBuilder salt = new StringBuilder();
		Random rnd = new Random();
		while (salt.length() < 8) { 
			int index = (int) (rnd.nextFloat() * SALTCHARS.length());
			salt.append(SALTCHARS.charAt(index));
		}
		String saltStr = salt.toString();
		return saltStr;
	}
	
	private void createSheet() throws IOException{
		Workbook workbook = new XSSFWorkbook();
		Sheet productSheet = workbook.createSheet("Product");
		Sheet priceSheet = workbook.createSheet("Price");
		Sheet registrationSheet = workbook.createSheet("Registration");
		Sheet orderConfirmationSheet = workbook.createSheet("Order Confirmation");
		Sheet orderHistorySheet = workbook.createSheet("Order History");
		
        String[] productColumns = {"Row Number", "Product Name", "Color", "Size", "Sku", "Qty", "Price"};
        String[] priceColumns = {"Row Number", "Total Products", "Total Shipping", "Total"};
        String[] registrationColumns = {"Row Number", "Registration Output", "Registration Values"};
        String[] orderConfirmationColumns = {"Row Number", "Amount"};
        String[] OrderHistoryColumns = {"Row Number", "Order History Attributes", "Order History Values"};
        
        Row headerRow = productSheet.createRow(0);
		for (int i = 0; i < productColumns.length; i++) {
		  Cell cell = headerRow.createCell(i);
		  cell.setCellValue(productColumns[i]);
		}		
	    
		headerRow = priceSheet.createRow(0);
		for (int i = 0; i < priceColumns.length; i++) {
			  Cell cell = headerRow.createCell(i);	
			  cell.setCellValue(priceColumns[i]);			  
			}
		
		headerRow = registrationSheet.createRow(0);
		for (int i = 0; i < registrationColumns.length; i++) {
			  Cell cell = headerRow.createCell(i);
			  cell.setCellValue(registrationColumns[i]);
			}		
	
		headerRow = orderConfirmationSheet.createRow(0);
		for (int i = 0; i < orderConfirmationColumns.length; i++) {
			  Cell cell = headerRow.createCell(i);
			  cell.setCellValue(orderConfirmationColumns[i]);
			}		
		
		headerRow = orderHistorySheet.createRow(0);
		for (int i = 0; i < OrderHistoryColumns.length; i++) {
			  Cell cell = headerRow.createCell(i);
			  cell.setCellValue(OrderHistoryColumns[i]);
			}
		
		int rowNum = 1;
		int count = 1;
		for(String[] item : product){			
			Row row = productSheet.createRow(rowNum++);
			row.createCell(0).setCellValue(count);
			row.createCell(1).setCellValue(item[0]);
			row.createCell(2).setCellValue(item[1]);
			row.createCell(3).setCellValue(item[2]);
			row.createCell(4).setCellValue(item[3]);
			row.createCell(5).setCellValue(item[4]);
			row.createCell(6).setCellValue(item[5]);
			count++;
		}
		
		rowNum = 1;
		count = 1;
		for(String[] item : priceList){
			Row row = priceSheet.createRow(rowNum++);
			row.createCell(0).setCellValue(count);
			row.createCell(1).setCellValue(item[0]);
			row.createCell(2).setCellValue(item[1]);
			row.createCell(3).setCellValue(item[2]);
			count++;
		}		

		rowNum = 1;
		count = 1;
		for(String[] item : registration){
			Row row = registrationSheet.createRow(rowNum++);
			row.createCell(0).setCellValue(count);
			row.createCell(1).setCellValue(item[0]);
			row.createCell(2).setCellValue(item[1]);
			count++;
		}
		
		rowNum = 1;
		count = 1;
		for(String[] item : orderConfirmation){
			Row row = orderConfirmationSheet.createRow(rowNum++);
			row.createCell(0).setCellValue(count);
			row.createCell(1).setCellValue(item[0]);
			count++;
		}
		
		rowNum = 1;
		count = 1;
		for(String[] item : orderHistory){
			Row row = orderHistorySheet.createRow(rowNum++);
			row.createCell(0).setCellValue(count);
			row.createCell(1).setCellValue(item[0]);
			row.createCell(2).setCellValue(item[1]);
			count++;
		}

		for (int i = 0; i < productColumns.length; i++) {
			 productSheet.autoSizeColumn(i);
			}
		
		for (int i = 0; i < priceColumns.length; i++) {
			 priceSheet.autoSizeColumn(i);
			}
		
		for (int i = 0; i < registrationColumns.length; i++) {
			 registrationSheet.autoSizeColumn(i);
			}

		for (int i = 0; i < orderConfirmationColumns.length; i++) {
			orderConfirmationSheet.autoSizeColumn(i);
			}
		
		for (int i = 0; i < OrderHistoryColumns.length; i++) {
			orderHistorySheet.autoSizeColumn(i);
			}
		//C:\Users\Admin\workspace\QET_Selenum\Excel_file
		//C:\\Users\\Admin\\Desktop\\Kamohelo_Letaoana.xlsx
		FileOutputStream fileOut = new FileOutputStream("C:\\Users\\Admin\\workspace\\QET_Selenum\\Excel_file\\Output.xlsx");
		workbook.write(fileOut);
		fileOut.close();
		workbook.close();
	}
	
	private void checkOut(){
		WebElement cart = driver.findElement(By.className("shopping_cart"));
		cart.click();
		
		WebElement proceedToCheckOut = driver.findElement(By.cssSelector("#center_column [title='Proceed to checkout']"));
		proceedToCheckOut.click();
		
		WebElement processAddress = driver.findElement(By.cssSelector("button[name='processAddress']"));
		processAddress.click();
		
		WebElement termsAgreement = driver.findElement(By.id("cgv"));
		termsAgreement.click();
		
		WebElement processCarrier = driver.findElement(By.cssSelector("button[name='processCarrier']"));
		processCarrier.click();
		
		WebElement bankWire = driver.findElement(By.cssSelector("a[title='Pay by bank wire']"));
		bankWire.click();
		
		WebElement confirmOrder = driver.findElement(By.xpath("//p[@id='cart_navigation']/button[@type='submit']"));
		confirmOrder.click();
		
		WebElement amountLabel = driver.findElement(By.cssSelector(".price > strong"));
		String amount = amountLabel.getText().substring(1);
		
		orderConfirmation.add(new String[] {amount});
				
		WebElement backToOrders = driver.findElement(By.cssSelector("a[title='Back to orders']"));
		backToOrders.click();
		
		orderHistory();
	}
	
	private void orderHistory(){
		WebElement historyTable = driver.findElement(By.id("order-list"));
		historyTable.click();
		
		List<WebElement> rows = historyTable.findElements(By.tagName("tr"));
		
		for(int i=1; i<rows.size(); i++){
			
			List<WebElement> colVals = rows.get(i).findElements(By.tagName("td"));
			String[] arr = new String[colVals.size()];
		  
			for(int j=0; j<colVals.size(); j++){
				arr[j] = colVals.get(j).getText();		
				}
			orderHistory.add(new String[] {"Order Reference", arr[0]});
			orderHistory.add(new String[] {"Date", arr[1]});
			orderHistory.add(new String[] {"Total price", arr[2].substring(1)});
			orderHistory.add(new String[] {"Payment", arr[3]});
			orderHistory.add(new String[] {"Status", arr[4]});
			}
	}
	
	@AfterMethod
	public void Cleanup() {
		driver.quit();
	}
	
	@AfterClass
	public void oneTimeTearDown() throws IOException {
		createSheet();
	}
}
