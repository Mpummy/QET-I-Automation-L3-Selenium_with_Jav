package testNG;

public class Registration {
	private String firstName;
	
	public void setFirstName(String newFirstName){
		this.firstName = newFirstName;
	}
	public String getFirstName(){
		return this.firstName;
	}
	private String lastName;
	public void setLastName(String newLastName){
		this.lastName = newLastName;
	}
	public String getLastName(){
		return this.lastName;
	}
	private String address;
	public void setAddress(String newAddress){
	 this.address = newAddress;	 
	}
	public String getAddress(){
	return this.address;
	}
	private String city;
	public void setCity(String newCity){
		this.city = newCity;
	}
	public String getCity(){
		return this.city;
	}
	private String state;
	public void setState(String newState){
		this.state = newState;
	}
	public String getState(){
		return this.state;
	}
	private String postalCode;
	public void setPostalCode(String newPostalCode){
		this.postalCode = newPostalCode;
	}
	public String getPostalCode(){
		return this.postalCode;
	}
	private String country;
	public void setCountry(String newCountry){
		this.country = newCountry;
	}
	public String getCountry(){
		return this.country;
	}
	private String mobile;
	public void setMobile(String newMobile){
		this.mobile = newMobile;
	}
	public String getMobile(){
		return this.mobile;
	}
	
	

}
