package testNG;

public class Product {
	private String name;
	  public String getName() {
	    return name;
	  }
	  public void setName(String newName) {
	    this.name = newName;
	  }
	  
	  private String color;		
		  public String getColor() {
		    return color;
		  }
		  public void setColor(String newColor) {
		    this.color = newColor;
		  }
		  
		  private String size;		
		  public String getSize() {
		    return size;
		  }
		  public void setSize(String newSize) {
		    this.size = newSize;
		  }
		  
		  private String sku;		
		  public String getSku() {
		    return sku;
		  }
		  public void setSku(String newSku) {
		    this.sku = newSku;
		  }
		  
		  private Integer  qty;		
		  public Integer  getQty() {
		    return qty;
		  }
		  public void setQty(Integer newQty) {
		    this.qty = newQty;
		  }
		  
		  private Float price;		
		  public Float getPrice() {
		    return price;
		  }
		  public void setPrice(Float newPrice) {
		    this.price = newPrice;
		  }
}
